var delay = null;

chrome.browserAction.onClicked.addListener(function (tab) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = tabs[0];
		var url = tab.url;
		var clipsUrl = !url.startsWith("https://clips.twitch.tv/");

		if (delay != null)
			clearTimeout(delay);

		delay = setTimeout(function () {
			chrome.browserAction.setIcon({ path: "images/icon.png" });
		}, 1250);

		if (clipsUrl) {
			chrome.browserAction.setIcon({ path: "images/icon_off.png" });
			return;
		}

		chrome.browserAction.setIcon({ path: "images/icon_valid.png" });

		var slug = /([A-Z])\w+/.exec(url)[0];
		chrome.storage.sync.get({
			redirection: false
		}, function (items) {
			chrome.tabs.update(tab.id, { url: 'http://clips.maner.fr/?clips=' + slug + (items.redirection ? "&type=mp4" : "") });
		});
	});
});