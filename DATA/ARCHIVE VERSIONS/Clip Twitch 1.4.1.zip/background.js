var delay = null;

chrome.browserAction.onClicked.addListener(function (cTab) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = tabs[0];
		var url = tab.url;
		var clipsUrl = !url.startsWith("https://clips.twitch.tv/");

		if (delay != null)
			clearTimeout(delay);

		delay = setTimeout(function () {
			chrome.browserAction.setIcon({ path: "images/icon.png" });
		}, 1250);

		if (clipsUrl) {
			chrome.browserAction.setIcon({ path: "images/icon_off.png" });
			return;
		}

		chrome.browserAction.setIcon({ path: "images/icon_valid.png" });

		var slug = /([A-Z])\w+/.exec(url)[0];

		chrome.storage.local.get({
			redirection: false
		}, function (items) {
			if (items.redirection)
				downloadMP4(slug);
			else
				chrome.tabs.update(tab.id, { url: 'http://clips.maner.fr/?clips=' + slug });
		});
	});
});

chrome.commands.onCommand.addListener(function (command) {
	if (command === "download-clip") {
		chrome.tabs.query({
			active: true,
			currentWindow: true
		}, function (tabs) {
			var url = tabs[0].url;

			if (!url.startsWith("https://clips.twitch.tv/"))
				return;

			var slug = /([A-Z])\w+/.exec(url)[0];
			downloadMP4(slug);
		});
	}
});

chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.greeting == "startDownloadMP4")
			downloadMP4(request.slug);
	});

var increment = 1;

function downloadMP4(slug) {
	var urlClip;
	var resClip;
	increment++;

	$.when(
		$.ajax({
			type: "GET",
			url: "https://clips.twitch.tv/api/v2/clips/" + slug + "/status",
			cache: false,
			async: true,
			success: function (res) {
				urlClip = res.quality_options[0].source;
			}
		}),
		$.ajax({
			type: "GET",
			url: "https://clips.twitch.tv/api/v2/clips/" + slug,
			cache: false,
			async: true,
			success: function (res) {
				resClip = res;
			}
		})
	).then(function () {
		chrome.storage.local.get({
			formatMP4: "{STREAMEUR}.{JEU} {TITRE}"
		}, function (items) {
			var fileName = items.formatMP4
				.replace("{CLIPEUR}", resClip.curator_display_name)
				.replace("{DUREE}", resClip.duration)
				.replace("{JEU}", resClip.game)
				.replace("{NOMBRE}", increment)
				.replace("{SLUG}", resClip.slug)
				.replace("{STREAMEUR}", resClip.broadcaster_display_name)
				.replace("{TITRE}", resClip.title)
				.replace("{VUES}", resClip.views);

			chrome.downloads.download({
				url: urlClip,
				filename: fileName + ".mp4"
			});
		});
	});
}

function checkChangelog() {
	var version = chrome.runtime.getManifest().version;

	chrome.storage.local.get({
		localVersion: "0.0.0"
	}, function (items) {
		if (items.localVersion != version)
			chrome.storage.local.set({
				localVersion: version,
			}, function () {
				chrome.tabs.create({ url: "http://clips.maner.fr/update.html" });
			});
	});
};

checkChangelog();