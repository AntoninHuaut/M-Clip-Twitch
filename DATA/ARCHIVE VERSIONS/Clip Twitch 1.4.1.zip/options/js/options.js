// Saves options to chrome.storage
function save_options() {
  var pRedirection = document.getElementById('redirection').checked;
  var pFormatMP4 = document.getElementById('formatMP4').value;
  if (invalidChars.some(char => pFormatMP4.indexOf(char) > -1)) {
    Materialize.toast('Erreur ! Le format présente des caractères non autorisés (/ ou \\' + ')', 3000)
    return;
  }

  chrome.storage.local.set({
    redirection: pRedirection,
    formatMP4: pFormatMP4
  }, function () {
    // Update status to let user know options were saved.
    Materialize.toast('Paramètres sauvegardés !', 1500)
  });
}

var invalidChars = ['/', '\\'];

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  chrome.storage.local.get({
    redirection: false,
    formatMP4: "{STREAMEUR}.{JEU} {TITRE}"
  }, function (items) {
    document.getElementById('redirection').checked = items.redirection;
    document.getElementById('formatMP4').value = items.formatMP4;
  });
}
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);