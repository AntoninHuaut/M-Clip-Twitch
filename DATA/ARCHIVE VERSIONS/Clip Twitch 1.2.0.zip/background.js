var delay = null;

chrome.browserAction.onClicked.addListener(function (tab) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = tabs[0];
		var url = tab.url;
		var clipsUrl = !url.startsWith("https://clips.twitch.tv/");

		if (delay != null)
			clearTimeout(delay);

		delay = setTimeout(function () {
			chrome.browserAction.setIcon({ path: "images/icon.png" });
		}, 1250);

		if (clipsUrl) {
			chrome.browserAction.setIcon({ path: "images/icon_off.png" });
			return;
		}

		chrome.browserAction.setIcon({ path: "images/icon_valid.png" });

		var slug = /([A-Z])\w+/.exec(url)[0];
		chrome.storage.sync.get({
			redirection: false
		}, function (items) {
			if (items.redirection)
				downloadMP4(slug);
			else
				chrome.tabs.update(tab.id, { url: 'http://clips.maner.fr/?clips=' + slug });
		});
	});
});

chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.greeting == "startDownloadMP4")
			downloadMP4(request.slug);
	});

function downloadMP4(slug) {
	$.ajax({
		type: "GET",
		url: "https://clips.twitch.tv/api/v2/clips/" + slug + "/status",
		cache: false,
		async: true,
		success: function (res) {
			chrome.downloads.download({
				url: res.quality_options[0].source,
				filename: slug + ".mp4"
			});
		}
	});
}