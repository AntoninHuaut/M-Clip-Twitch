timer = setInterval(editTwitch, 100);

function editTwitch() {
	var get = $('div.tw-align-items-center.tw-flex.tw-justify-content-end.tw-mg-y-1.tw-relative.tw-z-above');

	if (get.length == 0)
		return;

	clearInterval(timer);

	slug = /([A-Z])\w+/.exec(location.href)[0];

	get.prepend('<div class="tw-inline-block tw-mg-r-1"><div class="social-button"><div class="tw-inline-flex tw-tooltip-wrapper" aria-describedby="3647ab622ec3be445a328bb56b1ca35e"><div class="social-button__icon social-button__icon--facebook tw-align-items-center tw-flex tw-justify-content-center"><figure class="tw-svg"><a href="#"><img class="mp4ClipTwitch" src="https://i.imgur.com/TPUbVyZ.png" /></a></figure></div><div class="tw-tooltip tw-tooltip--align-center tw-tooltip--down" data-a-target="tw-tooltip-label" role="tooltip" id="3647ab622ec3be445a328bb56b1ca35e">Download MP4</div></div></div></div>');
	$(".mp4ClipTwitch").on("click", function () {
		chrome.runtime.sendMessage({ greeting: "startDownloadMP4", slug: slug });
	});
}