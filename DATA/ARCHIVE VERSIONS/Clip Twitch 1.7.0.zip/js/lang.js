var fr = {
    "options": {
        "redirection": {
            "description": "Redirection via l'icone (Sur un clip): ",
            "general": "Page général (http://clips.maner.fr)",
            "downloadMP4": "Téléchargement en MP4 (Meilleur qualité)"
        },
        "langue": "Langue",
        "format": {
            "description": "Choix des formats",
            "file": {
                "description": "Format (Nom du fichier) du fichier MP4: ",
                "balise": "Balises disponibles:",
                "nbInfos": "{NOMBRE}",
                "nbInfosItalic": "Augmente de 1 à chaque téléchargement de clip, réinitialise lorsque le navigateur est relancé"
            },
            "date": {
                "description": "Balise {DATE}: ",
                "listeFormat": "Liste de mise en forme disponible pour la balise DATE"
            },
            "tempsVOD": {
                "description": "Balise {TEMPS_VOD}: ",
                "infosItalic": "Indiquez ici le formatage de la balise lorsqu'il n'y a pas de VOD pour un clip"
            }
        },
        "boutons": {
            "save": "Sauvegarder",
            "change": "Changelog",
            "queue": "File d'attente"
        },
        "notif": {
            "error_caract": "Erreur ! Le format présente des caractères non autorisés (/ \\ ? ~ *)",
            "error_size": "Erreur ! La taille de l'image et du titre doit être un nombre supérieur ou égal à 0",
            "save_param": "Paramètres sauvegardés !"
        },
        "queue": {
            "description": "Configuration de la file d'attente",
            "tips": "Astuce: désactivez dans les paramètres de votre navigateur la popup de téléchargement de fichiers",
            "imageSize": {
                "description": "Taille de la prévisualisation (largeur vw)"
            },
            "titleSize": {
                "description": "Taille du titre (px)"
            }
        }
    },
    "queue": {
        "no_clip": "Votre file d'attente de clips est vide",
        "download_all": "Tout télécharger",
        "remove_all": "Tout supprimer",
        "back": "Retour"
    },
    "formatFile": [
        "{CLIPEUR}",
        "{DATE}",
        "{DUREE}",
        "{JEU}",
        "{NOMBRE}",
        "{SLUG}",
        "{STREAMEUR}",
        "{TEMPS_VOD}",
        "{TITRE}",
        "{VUES}"
    ]
};

var en = {
    "options": {
        "redirection": {
            "description": "Redirection from the icon (On a clip): ",
            "general": "General page (http://clips.maner.fr)",
            "downloadMP4": "Download in MP4 (Best quality)"
        },
        "langue": "Language",
        "format": {
            "description": "Choice of formats",
            "file": {
                "description": "Format (File name) of the MP4 file: ",
                "balise": "Available tags:",
                "nbInfos": "{NUMBER}",
                "nbInfosItalic": "Increases by 1 each time a clip is downloaded, resets when the browser is restarted"
            },
            "date": {
                "description": "{DATE} tag: ",
                "listeFormat": "Formatting list available for the DATE Tag"
            },
            "tempsVOD": {
                "description": "{TIME_VOD} tag: ",
                "infosItalic": "Specify here the formatting of the tag when there is no VOD for a clip"
            }
        },
        "boutons": {
            "save": "Save",
            "change": "Changelog",
            "queue": "Queue"
        },
        "notif": {
            "error_caract": "Error! The format has unauthorized characters (/ \\ ? ~ *)",
            "error_size": "Error! The size of the image and title must be a number greater than or equal to 0",
            "save_param": "Saved settings!"
        },
        "queue": {
            "description": "Configuring the queue",
            "tips": "Tip: disable the file download popup in your browser settings",
            "imageSize": {
                "description": "Clip preview size (width vw)"
            },
            "titleSize": {
                "description": "Clip title size (px)"
            }
        }
    },
    "queue": {
        "no_clip": "Your clip queue is empty",
        "download_all": "Download all",
        "remove_all": "Delete all",
        "back": "Back"
    },
    "formatFile": [
        "{CLIPPER}",
        "{DATE}",
        "{DURATION}",
        "{GAME}",
        "{NUMBRE}",
        "{SLUG}",
        "{STREAMER}",
        "{TIME_VOD}",
        "{TITLE}",
        "{VIEWS}"
    ]
};

function getLang(json, id) {
    let list = id.split('.');

    for (let i = 0; i < list.length; i++)
        json = json[list[i]];

    return json;
}