var langFile;
var invalidChars = ['/', '\\', '?', '~', '*'];

document.addEventListener("DOMContentLoaded", function (event) {
  setTimeout(function () {
    let list = document.getElementsByClassName("lang");
    langFile = (!chrome.extension.getBackgroundPage().lang ? fr : en);

    for (let i = 0; i < list.length; i++) {
      let element = list[i];
      element.innerText = getLang(langFile.options, element.id);
    }

    let tagList = "";

    for (let i = 0; i < langFile.formatFile.length; i++)
      tagList += " " + langFile.formatFile[i];

    document.getElementById("format.file.tagList").innerText = tagList;
    restore_options();
  }, 10);
});

function save_options() {
  let pRedirection = document.getElementById('redirection').checked;
  let pLanguage = document.getElementById('language').checked;
  let pFormatMP4 = document.getElementById('formatMP4').value;
  let pFormatDate = document.getElementById('format.date').value;
  let pFormatTempsVOD = document.getElementById('format.tempsVOD').value;
  let pQueueImageSize = document.getElementById('queue.imageSize').value;
  let pQueueTitleSize = document.getElementById('queue.titleSize').value;

  if (invalidChars.some(char => pFormatMP4.indexOf(char) > -1) ||
    invalidChars.some(char => pFormatDate.indexOf(char) > -1) ||
    invalidChars.some(char => pFormatTempsVOD.indexOf(char) > -1)) {
    Materialize.toast(langFile.options.notif.error_caract, 3000);
    return;
  }

  if (pQueueImageSize == "" || pQueueTitleSize == "" ||
    isNaN(pQueueImageSize) || isNaN(pQueueTitleSize) ||
    pQueueImageSize + 0 < 0 || pQueueTitleSize + 0 < 0) {
    Materialize.toast(langFile.options.notif.error_size, 3000);
    return;
  }

  let hasChange = false;

  chrome.storage.local.get({
    language: false
  }, function (items) {
    if (items.language != pLanguage) {
      hasChange = true;
      chrome.extension.getBackgroundPage().lang = pLanguage;
    }
  });

  chrome.storage.local.set({
    redirection: pRedirection,
    language: pLanguage,
    formatMP4: pFormatMP4,
    formatDate: pFormatDate,
    formatTempsVOD: pFormatTempsVOD,
    queueImageSize: pQueueImageSize,
    queueTitleSize: pQueueTitleSize
  }, function () {
    Materialize.toast(langFile.options.notif.save_param, 1500);

    if (hasChange)
      window.location.reload(false);
  });
}

function restore_options() {
  chrome.storage.local.get({
    redirection: false,
    language: false,
    formatMP4: "{STREAMER}.{GAME} {TITLE}",
    formatDate: "DD-MM-YYYY",
    formatTempsVOD: "-NA-",
    queueImageSize: "30",
    queueTitleSize: "20"
  }, function (items) {
    document.getElementById('redirection').checked = items.redirection;
    document.getElementById('language').checked = items.language;
    document.getElementById('formatMP4').value = items.formatMP4;
    document.getElementById('format.date').value = items.formatDate;
    document.getElementById('format.tempsVOD').value = items.formatTempsVOD;
    document.getElementById('queue.imageSize').value = items.queueImageSize;
    document.getElementById('queue.titleSize').value = items.queueTitleSize;

    $('#linkUpdateButton').attr("href", "http://clips.maner.fr/update_" + (items.language ? "en" : "fr") + ".html");
  });
}

document.getElementById('boutons.save').addEventListener('click', save_options);

document.getElementById('boutons.queue').addEventListener('click', function () {
  window.location.href = "../queue/queue.html";
});

function getBrowser() {
  return (navigator.userAgent.indexOf(' OPR/') > 0) ? 1 : (typeof InstallTrigger !== 'undefined') ? 3 : (!!window.chrome) ? 2 : 4;
}